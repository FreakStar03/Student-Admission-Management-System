package Frames;

import javax.swing.*;
import java.awt.*;

public class GuiGineOut extends JFrame{
    public GuiGineOut(){
        setTitle("Registration Form");
        setDefaultCloseOperation(EXIT_ON_CLOSE);//close java prog on close of window
        setSize(700, 500);//window size
        setLayout(null);//layout to null for window
        setLocationRelativeTo(null);//start window in center on monitor
        setResizable(false);//avoid window scaling

        //plane
        JPanel pane = new JPanel();
        pane.setLayout(null);
        pane.setBackground(Color.white);
        pane.setSize(800,500);
        setContentPane(pane);

        //construct components
        JLabel title = new JLabel ("Registration Form", JLabel.CENTER);
        JLabel email = new JLabel ("Email:");
        JLabel pw = new JLabel ("Password");
        JTextField emailField = new JTextField (5);
        JButton sub = new JButton ("Submit");
        JButton back = new JButton ("Back");
        JLabel cpw = new JLabel ("confirm password");
        JPasswordField pwField = new JPasswordField (5);
        JPasswordField cpwField = new JPasswordField (5);
        JLabel alertText = new JLabel ("Password must be 8 charaters long", JLabel.CENTER);

        //add components
        pane.add (title);
        pane.add (email);
        pane.add (pw);
        pane.add (emailField);
        pane.add (sub);
        pane.add (back);
        pane.add (cpw);
        pane.add (pwField);
        pane.add (cpwField);
        pane.add (alertText);

        //set component bounds (only needed by Absolute Positioning)
        title.setBounds (170, 20, 340, 45);
        email.setBounds (170, 100, 100, 25);
        pw.setBounds (160, 145, 100, 25);
        emailField.setBounds (355, 100, 150, 25);
        sub.setBounds (210, 305, 100, 25);
        back.setBounds (360, 305, 100, 25);
        cpw.setBounds (160, 190, 165, 25);
        pwField.setBounds (355, 145, 150, 25);
        cpwField.setBounds (355, 190, 150, 25);
        alertText.setBounds (180, 250, 315, 40);

        //STYLing

        //COurier Arial Serif
        title.setFont(new Font("Courier", Font.PLAIN, 20) );
        alertText.setFont(new Font("Arial", Font.PLAIN, 15) );
        title.setOpaque(true);
        title.setBackground(Color.green);
        title.setForeground(Color.GRAY);
        pane.setBackground(Color.LIGHT_GRAY);




        setVisible(true);
    }
}
