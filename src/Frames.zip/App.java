import Frames.GuiGineOut;
//import Frames.RegistrationFrame;

class App{
    public static void main(String args[]){
        //RegistrationFrame frame = new RegistrationFrame();
        GuiGineOut frame = new GuiGineOut();
    }
}